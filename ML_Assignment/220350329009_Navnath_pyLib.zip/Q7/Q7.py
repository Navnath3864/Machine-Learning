#Q7
import numpy as np
#here we use linspace because linspace take paramer like(start,end,number of element)
#so in linspace does not use steps size
arr=np.linspace(10,100,10)
print("The array of 10 element without using steps size\n")
print(arr)
