#Q2 
import numpy as np #np alias name
oneDarray = np.arange(0,40,4)

print("one Diamension array with step size 4:")
print(oneDarray)
